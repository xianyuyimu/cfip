#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
3x-ui 交互脚本实时汉化引擎
用法: zhify.py <原始 x-ui.sh> <输出文件>
纯文本替换 + 主菜单重排, 不改动任何逻辑分支/变量名/命令。
"""
import io
import re
import sys
import unicodedata


def dw(s):
    """终端显示宽度(中文按 2 列)"""
    return sum(2 if unicodedata.east_asian_width(c) in 'WF' else 1 for c in s)


# ============================================================
# 词条: 原文 -> 中文。按长度倒序应用, 避免短串抢先匹配。
# ============================================================
PAIRS = []


def T(old, new):
    PAIRS.append((old, new))


# ---------- 主菜单(整块重排, 这里仅兜底) ----------
# ---------- 状态 ----------
T("Panel state: ${green}Running${plain}", "面板状态: ${green}运行中${plain}")
T("Panel state: ${yellow}Not Running${plain}", "面板状态: ${yellow}未运行${plain}")
T("Panel state: ${red}Not Installed${plain}", "面板状态: ${red}未安装${plain}")
T("Start automatically: ${green}Managed by Docker${plain}", "开机自启: ${green}由 Docker 托管${plain}")
T("Start automatically: ${green}Yes${plain}", "开机自启: ${green}是${plain}")
T("Start automatically: ${red}No${plain}", "开机自启: ${red}否${plain}")
T("xray state: ${green}Running${plain}", "xray 状态: ${green}运行中${plain}")
T("xray state: ${red}Not Running${plain}", "xray 状态: ${red}未运行${plain}")
T("mtproto inbound ${id} (${bind}): ${green}Running${plain}",
  "mtproto 入站 ${id} (${bind}): ${green}运行中${plain}")
T("mtproto inbound ${id} (${bind}): ${red}Not Running${plain}",
  "mtproto 入站 ${id} (${bind}): ${red}未运行${plain}")

# ---------- 通用交互 ----------
T('read -rp "Choose an option: " choice', 'read -rp "请选择: " choice')
T('read -rp "Choose an option: " num', 'read -rp "请选择: " num')
T('read -rp "Choose an option: " pathChoice', 'read -rp "请选择: " pathChoice')
T('echo -e "${red}Invalid option. Please select a valid number.${plain}\\n"',
  'echo -e "${red}无效选项, 请输入正确的数字.${plain}\\n"')
T("0.${plain} Back to Main Menu", "0.${plain} 返回主菜单")
T('echo -e "\\nChoose an option:"', 'echo -e "\\n请选择:"')
T("Back to Main Menu", "返回主菜单")

# ---------- 主菜单条目(整块替换失败时的兜底) ----------
T("3X-UI Panel Management Script", "3X-UI 面板管理脚本")
T("0.${plain} Exit Script", "0.${plain} 退出脚本")
T("1.${plain} Install ", "1.${plain} 安装 ")
T("2.${plain} Update ", "2.${plain} 更新 ")
T("3.${plain} Update to Dev Channel (latest commit)", "3.${plain} 更新到 Dev 频道 (最新提交)")
T("4.${plain} Update Menu", "4.${plain} 更新菜单")
T("5.${plain} Legacy Version", "5.${plain} 历史版本 (降级)")
T("6.${plain} Uninstall", "6.${plain} 卸载")
T("7.${plain} Reset Username & Password", "7.${plain} 重置用户名和密码")
T("8.${plain} Reset Web Base Path", "8.${plain} 重置 Web 根路径")
T("9.${plain} Reset Settings", "9.${plain} 重置面板设置")
T("10.${plain} Change Port", "10.${plain} 修改面板端口")
T("11.${plain} View Current Settings", "11.${plain} 查看当前设置")
T("12.${plain} Start", "12.${plain} 启动")
T("13.${plain} Stop", "13.${plain} 停止")
T("14.${plain} Restart", "14.${plain} 重启面板")
T("15.${plain} Restart Xray", "15.${plain} 重启 Xray")
T("16.${plain} Check Status", "16.${plain} 查看运行状态")
T("17.${plain} Logs Management", "17.${plain} 日志管理")
T("18.${plain} Enable Autostart", "18.${plain} 开启开机自启")
T("19.${plain} Disable Autostart", "19.${plain} 关闭开机自启")
T("20.${plain} SSL Certificate Management", "20.${plain} SSL 证书管理")
T("21.${plain} Cloudflare SSL Certificate", "21.${plain} Cloudflare SSL 证书")
T("22.${plain} IP Limit Management", "22.${plain} IP 限制管理")
T("23.${plain} Firewall Management", "23.${plain} 防火墙管理")
T("24.${plain} SSH Port Forwarding Management", "24.${plain} SSH 端口转发管理")
T("25.${plain} PostgreSQL Management", "25.${plain} PostgreSQL 管理")
T("26.${plain} Enable BBR", "26.${plain} 启用 BBR")
T("27.${plain} Update Geo Files", "27.${plain} 更新 Geo 文件")
T("28.${plain} Speedtest by Ookla", "28.${plain} Ookla 测速")
T('read -rp "Please enter your selection [0-28]: " num', 'read -rp "请输入选项 [0-28]: " num')
T('LOGE "Please enter the correct number [0-28]"', 'LOGE "请输入正确的数字 [0-28]"')

# ---------- 日志 ----------
T("1.${plain} Debug Log", "1.${plain} 调试日志")
T("2.${plain} Clear All logs", "2.${plain} 清空全部日志")

# ---------- BBR ----------
T("1.${plain} Enable BBR", "1.${plain} 启用 BBR")
T("2.${plain} Disable BBR", "2.${plain} 停用 BBR")
T("BBR is not currently enabled.", "当前未启用 BBR.")
T("BBR has been replaced with CUBIC successfully.", "已成功用 CUBIC 替换 BBR.")
T("Failed to replace BBR with CUBIC. Please check your system configuration.",
  "BBR 替换为 CUBIC 失败, 请检查系统配置.")
T("BBR is already enabled!", "BBR 已处于启用状态!")
T("BBR has been enabled successfully.", "BBR 启用成功.")
T("Failed to enable BBR. Please check your system configuration.",
  "BBR 启用失败, 请检查系统配置.")

# ---------- 防火墙 ----------
T("1.${plain} ${green}Install${plain} Firewall", "1.${plain} ${green}安装${plain} 防火墙 (ufw)")
T("2.${plain} Port List [numbered]", "2.${plain} 端口规则列表 [带编号]")
T("3.${plain} ${green}Open${plain} Ports", "3.${plain} ${green}放行${plain} 端口")
T("4.${plain} ${red}Delete${plain} Ports from List", "4.${plain} ${red}删除${plain} 列表中的端口规则")
T("5.${plain} ${green}Enable${plain} Firewall", "5.${plain} ${green}启用${plain} 防火墙")
T("6.${plain} ${red}Disable${plain} Firewall", "6.${plain} ${red}停用${plain} 防火墙")
T("7.${plain} Firewall Status", "7.${plain} 防火墙状态")
T("ufw firewall is not installed. Installing now...", "ufw 防火墙未安装, 正在安装...")
T('read -rp "Enter the ports you want to open (e.g. 80,443,2053 or range 400-500): " ports',
  'read -rp "请输入要放行的端口 (示例 80,443,2053 或端口段 400-500): " ports')
T('read -rp "Enter your choice (1 or 2): " choice', 'read -rp "请输入选择 (1 或 2): " choice')
T('read -rp "Enter the rule numbers you want to delete (1, 2, etc.): " rule_numbers',
  'read -rp "请输入要删除的规则编号 (如 1, 2): " rule_numbers')
T('read -rp "Enter the ports you want to delete (e.g. 80,443,2053 or range 400-500): " ports',
  'read -rp "请输入要删除的端口 (示例 80,443,2053 或端口段 400-500): " ports')
T("Invalid choice. Please enter 1 or 2.", "选择无效, 请输入 1 或 2.")
T("Error: Invalid input. Please enter a comma-separated list of ports or a range of ports (e.g. 80,443,2053 or 400-500).",
  "错误: 输入无效, 请输入逗号分隔的端口或端口段 (示例 80,443,2053 或 400-500).")
T("Error: Invalid input. Please enter a comma-separated list of rule numbers.",
  "错误: 输入无效, 请输入逗号分隔的规则编号.")

# ---------- Geo ----------
T('run_geo_update "Loyalsoldier datasets"', 'run_geo_update "Loyalsoldier 数据"')
T('run_geo_update "chocolate4u datasets"', 'run_geo_update "chocolate4u 数据"')
T('run_geo_update "runetfreedom datasets"', 'run_geo_update "runetfreedom 数据"')
T('run_geo_update "geo files"', 'run_geo_update "Geo 文件"')
T(": download failed", ": 下载失败")
T(": already up to date", ": 已是最新")
T(": downloaded file is empty", ": 下载文件为空")
T(": failed to install", ": 安装失败")
T(": updated", ": 已更新")
T("could not be updated. Check the errors above.", "更新失败, 请检查上面的错误信息.")
T("have been updated successfully!", "更新成功!")
T("are already up to date, restart is not needed.", "已是最新, 无需重启.")
T("update_geofiles: unknown dataset", "更新 geo 文件: 未知数据集")
T("4.${plain} All", "4.${plain} 全部")

# ---------- IP 限制 / Fail2ban ----------
T("Install Fail2ban and configure IP Limit", "安装 Fail2ban 并配置 IP 限制")
T("2.${plain} Change Ban Duration", "2.${plain} 修改封禁时长")
T("3.${plain} Unban Everyone", "3.${plain} 解除全部封禁")
T("4.${plain} Ban Logs", "4.${plain} 封禁日志")
T("5.${plain} Ban an IP Address", "5.${plain} 封禁指定 IP")
T("6.${plain} Unban an IP Address", "6.${plain} 解封指定 IP")
T("7.${plain} Real-Time Logs", "7.${plain} 实时日志")
T("8.${plain} Service Status", "8.${plain} 服务状态")
T("9.${plain} Service Restart", "9.${plain} 重启服务")
T("10.${plain} Uninstall Fail2ban and IP Limit", "10.${plain} 卸载 Fail2ban 和 IP 限制")
T('confirm "Proceed with installation of Fail2ban & IP Limit?" "y"',
  'confirm "确认安装 Fail2ban 与 IP 限制?" "y"')
T('read -rp "Please enter new Ban Duration in Minutes [default 30]: " NUM',
  'read -rp "请输入新的封禁时长(分钟) [默认 30]: " NUM')
T('read -rp "Enter the IP address you want to ban: " ban_ip', 'read -rp "请输入要封禁的 IP: " ban_ip')
T('read -rp "Enter the IP address you want to unban: " unban_ip', 'read -rp "请输入要解封的 IP: " unban_ip')
T("1.${plain} Only remove IP Limit configurations", "1.${plain} 仅删除 IP 限制配置")
T("2.${plain} Uninstall Fail2ban and IP Limit", "2.${plain} 卸载 Fail2ban 与 IP 限制")
T("is not a number! Please, try again.", "不是数字, 请重新输入.")
T("All users Unbanned successfully.", "已成功解除全部封禁.")
T("Cancelled.", "已取消.")
T("has been banned successfully.", "封禁成功.")
T("has been unbanned successfully.", "解封成功.")
T("Invalid IP address format! Please try again.", "IP 地址格式无效, 请重试.")
T(", skipping Fail2ban setup.", ", 跳过 Fail2ban 配置.")
T("Fail2ban is not installed. Installing now...!", "Fail2ban 未安装, 正在安装...!")
T("Unsupported operating system. Please check the script and install the necessary packages manually.",
  "不支持的操作系统, 请检查脚本并手动安装所需软件包.")
T("Fail2ban installation failed.", "Fail2ban 安装失败.")
T("Fail2ban installed successfully!", "Fail2ban 安装成功!")
T("Fail2ban is already installed.", "Fail2ban 已安装.")
T("Configuring IP Limit...", "正在配置 IP 限制...")

# ---------- PostgreSQL ----------
T("1.${plain} ${green}Install${plain} PostgreSQL (server + client + xui db)",
  "1.${plain} ${green}安装${plain} PostgreSQL (服务端 + 客户端 + xui 库)")
T("2.${plain} Migrate SQLite ${green}->${plain} PostgreSQL", "2.${plain} 从 SQLite ${green}迁移到${plain} PostgreSQL")
T("3.${plain} Status (clusters & port 5432)", "3.${plain} 状态 (集群与 5432 端口)")
T("4.${plain} ${green}Start${plain} PostgreSQL", "4.${plain} ${green}启动${plain} PostgreSQL")
T("5.${plain} ${red}Stop${plain} PostgreSQL", "5.${plain} ${red}停止${plain} PostgreSQL")
T("6.${plain} Restart PostgreSQL", "6.${plain} 重启 PostgreSQL")
T("7.${plain} ${green}Enable${plain} Autostart on boot", "7.${plain} ${green}开启${plain} 开机自启")
T("8.${plain} View PostgreSQL Log", "8.${plain} 查看 PostgreSQL 日志")
T("9.${plain} Convert SQLite ${green}.db <-> .dump${plain}", "9.${plain} SQLite ${green}.db <-> .dump${plain} 互转")
T("10.${plain} Install/Upgrade client tools (pg_dump/pg_restore)",
  "10.${plain} 安装/升级客户端工具 (pg_dump/pg_restore)")
T('read -rp "Required PostgreSQL major version (empty = any): " pg_client_ver',
  'read -rp "指定 PostgreSQL 主版本 (留空表示任意版本): " pg_client_ver')
T('read -rp "Enter PostgreSQL DSN (postgres://user:pass@host:port/dbname?sslmode=disable): " dsn',
  'read -rp "请输入 PostgreSQL DSN (postgres://user:pass@host:port/dbname?sslmode=disable): " dsn')
T("Migrating data into PostgreSQL...", "正在迁移数据到 PostgreSQL...")
T("Migration failed. The panel was NOT switched to PostgreSQL.", "迁移失败, 面板未切换到 PostgreSQL.")
T("Wrote database settings to", "数据库配置已写入")
T("Restarting panel on PostgreSQL...", "正在以 PostgreSQL 重启面板...")
T("Migration complete. The panel is now running on PostgreSQL.", "迁移完成, 面板已运行在 PostgreSQL 上.")
T("Panel did not come up. Check logs (main menu option 17). Your SQLite data is left intact.",
  "面板未能启动, 请查看日志 (主菜单 17). 你的 SQLite 数据保持完好.")
T("Refusing to restore into the live database", "拒绝还原到使用中的数据库")
T("while x-ui is running.", "因为 x-ui 正在运行.")
T("Stop the panel first (x-ui stop) or choose a different output path.",
  "请先停止面板 (x-ui stop) 或换一个输出路径.")
T("is not installed. Is the panel installed?", "未安装, 面板是否已安装?")
T("This x-ui build does not support .db <-> .dump conversion yet.", "当前 x-ui 版本还不支持 .db <-> .dump 转换.")
T("Update the panel first (x-ui update) to a version with 'migrate-db --dump/--restore'.",
  "请先更新面板 (x-ui update) 到支持 migrate-db --dump/--restore 的版本.")
T("Input file not found:", "输入文件不存在:")
T("Input file [${default_db}]: ", "输入文件 [${default_db}]: ")
T("Output file (leave empty to auto-name next to input): ", "输出文件 (留空则自动命名到输入文件同目录): ")
T("Output", "输出文件")
T("already exists and will be overwritten. Continue?", "已存在且会被覆盖, 是否继续?")
T("Dumping SQLite database to SQL text:", "正在把 SQLite 数据库导出为 SQL 文本:")
T("Rebuilding SQLite database from SQL text:", "正在从 SQL 文本重建 SQLite 数据库:")
T("Done. Wrote", "完成, 已写入")
T("Done. Created", "完成, 已生成")
T("Dump failed.", "导出失败.")
T("Restore failed.", "还原失败.")
T("Convert between a SQLite", "在 SQLite")
T("and a portable", "与便携")
T("(direction auto-detected).", "之间转换 (自动识别方向).")
T("This panel was using PostgreSQL.", "本面板此前使用 PostgreSQL.")
T("purging removes the PostgreSQL server and", "清除操作会删除 PostgreSQL 服务端以及其")
T("of its databases on", "的全部数据库, 位置在")
T("this machine, including any used by other applications. This cannot be undone.",
  "本机上, 包括其他应用正在使用的库. 此操作不可撤销.")
T('confirm "Also purge PostgreSQL and delete all of its data?" "n"',
  'confirm "是否一并清除 PostgreSQL 并删除其全部数据?" "n"')
T("Left PostgreSQL installed; its data was not removed.", "已保留 PostgreSQL, 其数据未被删除.")
T("This copies your current SQLite data into a PostgreSQL database,",
  "此操作会把当前 SQLite 数据复制到 PostgreSQL 数据库,")
T("then switches the panel to PostgreSQL and restarts it.", "然后切换面板到 PostgreSQL 并重启.")
T("Any existing panel tables in the destination will be cleared and overwritten.",
  "目标库中已存在的面板数据表将被清空并覆盖.")
T('confirm "Continue?" "n"', 'confirm "继续?" "n"')
T("A PostgreSQL database was created in this session:", "本次会话中已创建 PostgreSQL 数据库:")
T('confirm "Migrate into this database?" "y"', 'confirm "是否迁移到此数据库?" "y"')
T("1.${plain} Install PostgreSQL locally and create a dedicated user/db (recommended)",
  "1.${plain} 本机安装 PostgreSQL 并创建专用用户/库 (推荐)")
T("Usage: ${green}x-ui migrateDB", "用法: ${green}x-ui migrateDB")

# ---------- SSH 端口转发 ----------
T("Standard SSH command:", "标准 SSH 命令:")
T("If using SSH key:", "如使用 SSH 密钥:")
T("After connecting, access the panel at:", "连接成功后请访问面板:")
T("1.${plain} Set listen IP", "1.${plain} 设置监听 IP")
T("2.${plain} Clear listen IP", "2.${plain} 清除监听 IP")
T("No listenIP configured. Choose an option:", "未配置 listenIP, 请选择:")
T("1. Use default IP (127.0.0.1)", "1. 使用默认 IP (127.0.0.1)")
T("2. Set a custom IP", "2. 自定义 IP")
T('read -rp "Select an option (1 or 2): " listen_choice', 'read -rp "请选择 (1 或 2): " listen_choice')
T('read -rp "Enter custom IP to listen on: " config_listenIP', 'read -rp "请输入自定义监听 IP: " config_listenIP')

# ---------- SSL 证书 ----------
T("1.${plain} Get SSL (Domain)", "1.${plain} 申请 SSL 证书 (域名)")
T("2.${plain} Revoke & Remove", "2.${plain} 吊销并移除证书")
T("3.${plain} Force Renew", "3.${plain} 强制续期")
T("4.${plain} Show Existing Domains", "4.${plain} 查看已有域名")
T("5.${plain} Set Cert paths for the panel", "5.${plain} 设置面板证书路径")
T("6.${plain} Get SSL for IP Address (6-day cert, auto-renews)",
  "6.${plain} 为 IP 申请 SSL 证书 (6 天有效期, 自动续期)")
T('read -rp "Please enter a domain from the list to revoke and remove the certificate: " domain',
  'read -rp "请输入要吊销并移除证书的域名: " domain')
T('read -rp "Please enter a domain from the list to renew the SSL certificate: " domain',
  'read -rp "请输入要续期 SSL 证书的域名: " domain')
T("2.${plain} Enter custom certificate file paths (e.g. certbot, /etc/letsencrypt/...)",
  "2.${plain} 手动输入证书文件路径 (如 certbot, /etc/letsencrypt/...)")
T('read -rp "Please choose a domain to set the panel paths: " domain',
  'read -rp "请选择要设置面板证书路径的域名: " domain')
T("Domain: ", "域名: ")
T("Certificate Path: ", "证书路径: ")
T("Private Key Path: ", "私钥路径: ")
T(" - Certificate or Key missing.", " - 证书或私钥缺失.")
T("Panel certificate (custom path): ", "面板证书 (自定义路径): ")
T("Covers: ", "覆盖域名: ")
T("1.${plain} Use a certificate from /root/cert", "1.${plain} 使用 /root/cert 目录中的证书")
T("Let's Encrypt SSL Certificate for IP Address", "为 IP 地址申请 Let's Encrypt SSL 证书")
T("This will obtain a certificate for your server's IP using the shortlived profile.",
  "将使用 shortlived 配置为服务器 IP 申请证书.")
T("Certificate valid for ~6 days, auto-renews via acme.sh cron job.",
  "证书有效期约 6 天, 由 acme.sh 定时任务自动续期.")
T("Port 80 must be open and accessible from the internet.", "80 端口必须开放且可从公网访问.")
T('read -rp "Please enter your server\'s public IPv4 address: " server_ip',
  'read -rp "请输入服务器的公网 IPv4 地址: " server_ip')
T('read -rp "Enter another port for acme.sh standalone listener (leave empty to abort): " alt_port',
  'read -rp "请输入 acme.sh 独立监听用的备用端口 (留空则放弃): " alt_port')
T('read -rp "Please enter your domain name: " domain', 'read -rp "请输入你的域名: " domain')
T("Invalid domain format:", "域名格式无效:")
T(". Please enter a valid domain name.", ", 请输入正确的域名.")
T('read -rp "Please choose which port to use (default is 80): " WebPort',
  'read -rp "请选择使用的端口 (默认 80): " WebPort')
T('read -rp "Port to use for ACME HTTP-01 listener (default 80): " WebPort',
  'read -rp "ACME HTTP-01 校验监听端口 (默认 80): " WebPort')
T('read -rp "Please enter your reloadcmd (example: systemctl reload nginx ; x-ui restart): " reloadCmd',
  'read -rp "请输入重载命令 (示例: systemctl reload nginx ; x-ui restart): " reloadCmd')
T("1.${plain} Preset: systemctl reload nginx ; x-ui restart", "1.${plain} 预设: systemctl reload nginx ; x-ui restart")
T("2.${plain} Input your own command", "2.${plain} 自定义命令")
T("0.${plain} Keep default reloadcmd", "0.${plain} 保持默认 reloadcmd")
T('read -rp "Generate SSL certificate for IP now? [y/N]: " gen_ssl', 'read -rp "现在为 IP 生成 SSL 证书? [y/N]: " gen_ssl')
T('read -rp "Certificate file path (fullchain): " webCertFile', 'read -rp "证书文件路径 (fullchain): " webCertFile')
T('read -rp "Private key file path: " webKeyFile', 'read -rp "私钥文件路径: " webKeyFile')
T('read -rp "Do you have an IPv6 address to include? (leave empty to skip): " ipv6_addr',
  'read -rp "是否有需要包含的 IPv6 地址? (留空跳过): " ipv6_addr')
T('read -rp "Would you like to set this certificate for the panel? (y/n): " setPanel',
  'read -rp "是否将此证书设置为面板证书? (y/n): " setPanel')
T('read -rp "Would you like to modify --reloadcmd for ACME? (y/n): " setReloadcmd',
  'read -rp "是否修改 ACME 的 --reloadcmd? (y/n): " setReloadcmd')
T('read -rp "Input your domain here: " CF_Domain', 'read -rp "请输入你的域名: " CF_Domain')
T('read -rp "Are you using a Cloudflare API Token or Global API Key? (t/g) [Default t]: " CF_KeyType',
  'read -rp "使用 Cloudflare API Token 还是 Global API Key? (t/g) [默认 t]: " CF_KeyType')
T('read -rp "Input your key here: " CF_GlobalKey', 'read -rp "请输入 Key: " CF_GlobalKey')
T('read -rp "Input your email here: " CF_AccountEmail', 'read -rp "请输入邮箱: " CF_AccountEmail')
T('read -rp "Input your token here: " CF_ApiToken', 'read -rp "请输入 Token: " CF_ApiToken')

# ---------- 重置/设置 ----------
T('read -rp "Please set the login username [default is a random username]: " config_account',
  'read -rp "请设置登录用户名 [默认随机生成]: " config_account')
T('read -rp "Please set the login password [default is a random password]: " config_password',
  'read -rp "请设置登录密码 [默认随机生成]: " config_password')
T('read -rp "Do you want to disable currently configured two-factor authentication? (y/n): " twoFactorConfirm',
  'read -rp "是否关闭当前已配置的两步验证? (y/n): " twoFactorConfirm')
T('read -rp "Are you sure you want to reset the web base path? (y/n): " confirm',
  'read -rp "确认重置 Web 根路径? (y/n): " confirm')
T("Two factor authentication has been disabled.", "两步验证已关闭.")
T("Panel login username has been reset to: ", "面板登录用户名已重置为: ")
T("Panel login password has been reset to: ", "面板登录密码已重置为: ")
T("Please use the new login username and password to access the X-UI panel. Also remember them!",
  "请使用新的用户名和密码登录 X-UI 面板, 并务必牢记!")
T("Resetting Web Base Path", "正在重置 Web 根路径")
T("Operation canceled.", "操作已取消.")
T("Web base path has been reset to: ", "Web 根路径已重置为: ")
T("Please use the new web base path to access the panel.", "请使用新的 Web 根路径访问面板.")
T("All panel settings have been reset to default.", "面板全部设置已恢复默认.")
T("Database: PostgreSQL — ", "数据库: PostgreSQL — ")
T("Database: SQLite (/etc/x-ui/x-ui.db)", "数据库: SQLite (/etc/x-ui/x-ui.db)")
T('echo -n "Enter port number[1-65535]: "', 'echo -n "请输入端口号 [1-65535]: "')
T('echo -n "Enter the panel version (like 2.4.0):"', 'echo -n "请输入面板版本 (如 2.4.0):"')
T("Could not auto-detect server IP from any provider.", "无法从任何来源自动获取服务器 IP.")
T("Invalid IPv4 address. Please try again.", "IPv4 地址无效, 请重试.")
T("WARNING: No SSL certificate configured!", "警告: 尚未配置 SSL 证书!")
T("You can get a Let's Encrypt certificate for your IP address (valid ~6 days, auto-renews).",
  "可以为你的 IP 申请 Let's Encrypt 证书 (有效期约 6 天, 自动续期).")
T("You can try again via main menu option 20 (SSL Certificate Management).",
  "可通过主菜单 20 (SSL 证书管理) 重试.")
T("For security, please configure SSL certificate using main menu option 20 (SSL Certificate Management)",
  "出于安全考虑, 请通过主菜单 20 (SSL 证书管理) 配置 SSL 证书")
T("Access URL: ", "访问地址: ")
T("The port is set, Please restart the panel now, and use the new port", "端口已设置, 请立即重启面板, 并使用新端口")
T("to access web panel", "访问面板")

# ---------- 更新/卸载 ----------
T("No x-ui.sh published for the installed version", "当前版本没有发布对应的 x-ui.sh")
T(", using main", ", 改用 main 分支")
T("Updating Menu", "正在更新菜单脚本")
T("This function will update the menu to the latest changes.", "此功能会把菜单脚本更新到最新版本.")
T("Update successful. The panel has automatically restarted.", "更新成功, 面板已自动重启.")
T("Failed to update the menu.", "更新菜单脚本失败.")
T("Uninstalled Successfully.", "卸载成功.")

# ---------- 命令帮助 show_usage ----------
T("x-ui control menu usages (subcommands):", "x-ui 控制菜单用法 (子命令):")
T("- Admin Management Script", "- 管理脚本(交互菜单)")
T("- Start", "- 启动")
T("- Stop", "- 停止")
T("- Restart Xray", "- 重启 Xray")
T("- Restart", "- 重启")
T("- Current Status", "- 当前状态")
T("- Current Settings", "- 当前设置")
T("- Enable Autostart on OS Startup", "- 开启开机自启")
T("- Disable Autostart on OS Startup", "- 关闭开机自启")
T("- Check logs", "- 查看日志")
T("- Check Fail2ban ban logs", "- 查看 Fail2ban 封禁日志")
T("- Update to Dev channel (latest)", "- 更新到 Dev 频道 (最新)")
T("- Update all geo files", "- 更新全部 geo 文件")
T("- Update", "- 更新")
T("- Convert .db <-> .dump (SQLite)", "- SQLite .db <-> .dump 互转")
T("- Upgrade pg_dump/pg_restore tools", "- 升级 pg_dump/pg_restore 工具")
T("- Legacy version", "- 历史版本")
T("- Install", "- 安装")
T("- Uninstall", "- 卸载")


# ---------- 安装检查 ----------
T("Please install the panel first", "请先安装面板")
T('read -rp "Choose [1]: " pg_mode', 'read -rp "请选择 [1]: " pg_mode')
T("Panel installed, Please do not reinstall", "面板已安装, 请勿重复安装")

# ---------- 通用 ----------
T("Failed to download x-ui.sh", "下载 x-ui.sh 失败")
T("Downloaded x-ui.sh is empty", "下载的 x-ui.sh 为空")
T("Failed to install x-ui.sh", "安装 x-ui.sh 失败")
T("acme.sh is already installed.", "acme.sh 已安装.")
T("Press any key to continue", "按任意键继续")
T("Please enter", "请输入")
T("Are you sure", "确认")
T("Successfully", "成功")
T("successfully!", "成功!")
T("Failed to", "失败:")
T("failed!", "失败!")
T("done.", "完成.")
T("Done.", "完成.")
T("System", "系统")

# ============================================================
# 主菜单整块重排(保证中文双宽对齐)
# ============================================================
G, P = '${green}', '${plain}'
MW = 48
BW = MW + 2      # 顶/底框横线长度
SEP = "│" + "─" * BW + "│"


def _row(text, num=None, colored=False):
    vis = f"{num}. {text}" if num else text
    pad = " " * max(0, MW - dw(vis))
    body = f"{G}{num}.{P} {text}" if num else (f"{G}{text}{P}" if colored else text)
    return f"│  {body}{pad}│"


MENU_ROWS = [
    _row("3X-UI 面板管理脚本", colored=True),
    _row("退出脚本", "0"),
    "SEP",
    _row("安装", "1"),
    _row("更新", "2"),
    _row("更新到 Dev 频道 (最新提交)", "3"),
    _row("更新菜单", "4"),
    _row("历史版本 (降级)", "5"),
    _row("卸载", "6"),
    "SEP",
    _row("重置用户名和密码", "7"),
    _row("重置 Web 根路径", "8"),
    _row("重置面板设置", "9"),
    _row("修改面板端口", "10"),
    _row("查看当前设置", "11"),
    "SEP",
    _row("启动", "12"),
    _row("停止", "13"),
    _row("重启", "14"),
    _row("重启 Xray", "15"),
    _row("查看状态", "16"),
    _row("日志管理", "17"),
    "SEP",
    _row("开启开机自启", "18"),
    _row("关闭开机自启", "19"),
    "SEP",
    _row("SSL 证书管理", "20"),
    _row("Cloudflare SSL 证书", "21"),
    _row("IP 限制管理", "22"),
    _row("防火墙管理", "23"),
    _row("SSH 端口转发管理", "24"),
    _row("PostgreSQL 管理", "25"),
    "SEP",
    _row("启用 BBR", "26"),
    _row("更新 Geo 文件", "27"),
    _row("Ookla 测速", "28"),
]
MENU_BLOCK = ('    echo -e "\n' + "╔" + "─" * BW + "╗\n"
              + "\n".join(SEP if r == "SEP" else r for r in MENU_ROWS)
              + "\n" + "╚" + "─" * BW + "╝" + '\n"\n')


def replace_menu(s):
    """把 show_menu() 里的菜单打印块整块换成对齐的中文版。"""
    try:
        fn = s.index("show_menu() {")
    except ValueError:
        return s
    m = re.search(r'echo -e "\s*╔', s[fn:])
    if not m:
        return s
    start = fn + m.start()
    # 从框线末尾开始找结束引号(echo -e " 后面紧跟换行, 不能从 start 找)
    bar = s.index('╗', start) + 1
    endm = s.find('"\n', bar)
    if endm < 0:
        return s
    return s[:start] + MENU_BLOCK + s[endm + 2:]


def main():
    if len(sys.argv) < 3:
        sys.stderr.write("usage: zhify.py <src> <out>\n")
        return 2
    src, out = sys.argv[1], sys.argv[2]
    s = io.open(src, encoding='utf-8').read()

    s = replace_menu(s)

    # 长串优先, 避免短串抢先吃掉
    for old, new in sorted(PAIRS, key=lambda x: -len(x[0])):
        s = s.replace(old, new)

    io.open(out, 'w', encoding='utf-8').write(s)
    return 0


if __name__ == '__main__':
    sys.exit(main())
