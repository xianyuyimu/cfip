#!/usr/bin/env bash
# 一行命令安装 3x-ui 中文菜单
# 用法: bash <(curl -Ls https://你的地址/bootstrap.sh)
# 或本地: bash bootstrap.sh
set -u
DEST=/tmp/3xui-zh-install
BASE="${3XUI_ZH_BASE:-}"
if [[ -n "$BASE" ]]; then
    mkdir -p "$DEST"
    curl -fsSL -o "$DEST/install-zh.sh" "$BASE/install-zh.sh" || exit 1
    curl -fsSL -o "$DEST/zhify.py"    "$BASE/zhify.py"    || exit 1
    cd "$DEST"
else
    cd "$(dirname "$0")"
fi
[[ $EUID -ne 0 ]] && { echo "请用 root 运行"; exit 1; }
bash install-zh.sh
