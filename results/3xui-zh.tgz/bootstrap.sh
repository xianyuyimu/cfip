#!/usr/bin/env bash
# ============================================================
# 3x-ui 中文菜单 —— 一键安装(从 GitHub 拉取)
#
# ★★★ 上传到 GitHub 后, 只需要改下面这一行 ★★★
#      把 你的用户名 和 仓库名 换成你自己的
# ============================================================
GITHUB_REPO="你的用户名/3xui-zh"      # ← 改这里, 例如 abcd1234/3xui-zh
GITHUB_BRANCH="${GITHUB_BRANCH:-main}"  # 分支, 默认 main

# ============================================================
set -uo pipefail

REPO="${GITHUB_REPO}"
BRANCH="${GITHUB_BRANCH}"
# 允许用环境变量临时覆盖
[[ -n "${GITHUB_REPO_OVERRIDE:-}" ]] && REPO="$GITHUB_REPO_OVERRIDE"

DEST="/tmp/3xui-zh-install"
R='\033[0;31m'; G='\033[0;32m'; Y='\033[0;33m'; P='\033[0m'

[[ $EUID -ne 0 ]] && { echo -e "${R}请用 root 运行${P}"; exit 1; }

if [[ "$REPO" == *"你的用户名"* ]]; then
    echo -e "${R}还没配置仓库地址${P}"
    echo "请编辑本文件, 把 GITHUB_REPO 改成你的用户名/仓库名"
    echo "或这样直接指定:"
    echo "  GITHUB_REPO_OVERRIDE=用户名/仓库名 bash <(curl -Ls ...)"
    exit 1
fi

# 依赖检查
if ! command -v curl >/dev/null 2>&1; then
    echo -e "${Y}未找到 curl, 正在安装...${P}"
    if   command -v apt-get >/dev/null 2>&1; then apt-get update -qq && apt-get install -y curl
    elif command -v dnf     >/dev/null 2>&1; then dnf install -y curl
    elif command -v yum     >/dev/null 2>&1; then yum install -y curl
    elif command -v apk     >/dev/null 2>&1; then apk add --no-cache curl
    fi
fi
if ! command -v python3 >/dev/null 2>&1; then
    echo -e "${Y}未找到 python3, 正在安装...${P}"
    if   command -v apt-get >/dev/null 2>&1; then apt-get update -qq && apt-get install -y python3
    elif command -v dnf     >/dev/null 2>&1; then dnf install -y python3
    elif command -v yum     >/dev/null 2>&1; then yum install -y python3
    elif command -v apk     >/dev/null 2>&1; then apk add --no-cache python3
    fi
fi
command -v python3 >/dev/null 2>&1 || { echo -e "${R}python3 安装失败, 请手动安装${P}"; exit 1; }

echo -e "${G}[*]${P} 仓库: $REPO  分支: $BRANCH"
mkdir -p "$DEST" && cd "$DEST" || exit 1

fetch() {
    local name="$1" url code
    url="https://raw.githubusercontent.com/${REPO}/${BRANCH}/${name}"
    for i in 1 2 3; do
        code=$(curl -fsSL --max-time 30 -w '%{http_code}' -o "$name.tmp" "$url" 2>/dev/null)
        if [[ "$code" == "200" && -s "$name.tmp" ]]; then
            mv -f "$name.tmp" "$name"
            return 0
        fi
        rm -f "$name.tmp"
        echo -e "${Y}[!] 下载 $name 失败(HTTP ${code:-超时}), 第 $i 次重试...${P}"
        sleep 2
    done
    return 1
}

fetch install-zh.sh || {
    echo -e "${R}拉取 install-zh.sh 失败${P}"
    echo "  检查: 1) 仓库是否公开  2) 用户名/仓库名是否写对  3) 分支名是否正确(默认 main)"
    exit 1
}
fetch zhify.py || { echo -e "${R}拉取 zhify.py 失败${P}"; exit 1; }

python3 -c "import ast;ast.parse(open('zhify.py',encoding='utf-8').read())" 2>/dev/null \
    || { echo -e "${R}zhify.py 校验失败, 文件可能损坏${P}"; exit 1; }

echo -e "${G}[✓]${P} 文件下载完成, 开始安装"
echo
bash install-zh.sh
