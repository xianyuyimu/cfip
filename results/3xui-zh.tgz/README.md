# 3x-ui 中文菜单

把 3x-ui 的 `x-ui` 交互命令汉化。**装一次，上游升级也不会丢。**

## 原理

3x-ui 升级时会直接覆盖 `/usr/bin/x-ui`，所以改原文件没用。

本方案不动原文件，在 `/usr/local/bin/x-ui` 放一层 wrapper（优先级高于 `/usr/bin`），
每次执行时实时拉取对应版本的上游脚本、汉化、再执行。

```
你敲 x-ui
   ↓
/usr/local/bin/x-ui   ← wrapper(汉化层)
   ↓ 读取已安装版本
v3.11.0/x-ui.sh  (上游原始脚本)
   ↓ 实时汉化
执行
```

## 安装

### 方式一：一行命令（推荐）

```bash
bash <(curl -Ls https://raw.githubusercontent.com/你的用户名/3xui-zh/main/bootstrap.sh)
```

### 方式二：下载压缩包

```bash
wget https://github.com/你的用户名/3xui-zh/archive/refs/heads/main.tar.gz -O z.tgz
tar xzf z.tgz && cd 3xui-zh-main
bash install-zh.sh
```

### 方式三：git clone

```bash
git clone https://github.com/你的用户名/3xui-zh.git
cd 3xui-zh
bash install-zh.sh
```

## 文件说明

| 文件 | 作用 |
|---|---|
| `bootstrap.sh` | 引导脚本，从 GitHub 拉取另两个文件后安装 |
| `install-zh.sh` | 安装器，部署 wrapper 和汉化引擎 |
| `zhify.py` | 汉化引擎，文本替换 + 菜单重排 |

## 装好之后的命令

| 命令 | 作用 |
|---|---|
| `x-ui` | 中文菜单（默认） |
| `x-ui-zh-fix` | 上游大改后强制重新拉取并汉化 |
| `x-ui-zh-off` | 临时切回原版英文 |
| `x-ui-zh-uninstall` | 彻底卸载，恢复原版 |

## 安全性

- 只替换用户可见文案：菜单项、`read -rp` 提示、状态行、错误提示
- `case` 分支、变量名、`start`/`stop`/`restart` 等子命令逻辑一个字符没动
- 汉化后先过 `bash -n` 语法校验，不过就降级跑原始脚本
- 用 `show_menu`、`check_install` 两个结构锚点判断上游脚本是否被大改

## 卸载

```bash
x-ui-zh-uninstall
```
