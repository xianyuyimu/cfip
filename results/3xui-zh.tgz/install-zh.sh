#!/usr/bin/env bash
# ============================================================
# 3x-ui 中文菜单 —— 一次装上, 永久生效
#   /usr/local/bin/x-ui  (wrapper, 每次执行时实时汉化上游脚本)
#   /etc/3xui-zh/zhify.py (汉化引擎)
#   /etc/3xui-zh/upstream.sh (上游原始脚本缓存)
#   /usr/local/bin/x-ui-zh-* (管理命令)
#
# 升级/更新菜单时上游会覆盖 /usr/bin/x-ui, 但那只是原始脚本,
# 用户敲的 x-ui 永远走 wrapper, 所以汉化不会丢。
# ============================================================
set -uo pipefail

ZDIR=/etc/3xui-zh
UPSTREAM=/usr/bin/x-ui
WRAPPER=/usr/local/bin/x-ui
RAW_MAIN="https://raw.githubusercontent.com/MHSanaei/3x-ui/main/x-ui.sh"

R='\033[0;31m'; G='\033[0;32m'; Y='\033[0;33m'; B='\033[0;34m'; P='\033[0m'
# 用 printf 而非 echo -e: 某些系统的 /bin/sh 与 busybox echo 不解析 \033,
# 会导致颜色码原样打印。printf 在所有 shell 下行为一致。
ok()   { printf "${G}[✓]${P} %s\n" "$*"; }
warn() { printf "${Y}[!]${P} %s\n" "$*"; }
err()  { printf "${R}[✗]${P} %s\n" "$*" >&2; }

[[ $EUID -ne 0 ]] && { err "请用 root 运行"; exit 1; }

HERE="$(cd "$(dirname "$0")" && pwd)"

# ---------- 1. 汉化引擎 ----------
install -d "$ZDIR"
if [[ -f "$HERE/zhify.py" ]]; then
    install -m 0644 "$HERE/zhify.py" "$ZDIR/zhify.py"
else
    err "缺少 zhify.py, 请把它和本脚本放在同一目录"
    exit 1
fi
ok "汉化引擎已安装: $ZDIR/zhify.py"

# ---------- 2. 备份现状 ----------
if [[ -f "$WRAPPER" ]] && ! grep -q "3xui-zh wrapper" "$WRAPPER" 2>/dev/null; then
    cp -f "$WRAPPER" "$WRAPPER.bak.$(date +%s)"
    warn "已备份原 $WRAPPER"
fi
if [[ -f "$UPSTREAM" ]] && [[ ! -f "$ZDIR/original-x-ui.sh" ]]; then
    cp -f "$UPSTREAM" "$ZDIR/original-x-ui.sh"
fi

# ---------- 3. wrapper ----------
cat > "$WRAPPER" << 'WRAPEOF'
#!/usr/bin/env bash
# 3xui-zh wrapper —— 实时汉化上游脚本后执行
ZH_DIR=/etc/3xui-zh
UPSTREAM=/usr/bin/x-ui
CACHE=$ZH_DIR/upstream.sh
RAW_MAIN="https://raw.githubusercontent.com/MHSanaei/3x-ui/main/x-ui.sh"

# 解析应使用的上游脚本地址(与上游 installed_script_url 同逻辑)
pick_url() {
    local ver=""
    if [[ -x /etc/x-ui/x-ui ]]; then
        ver=$(/etc/x-ui/x-ui -v 2>/dev/null | tr -d '[:space:]')
    fi
    if [[ "$ver" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
        local u="https://raw.githubusercontent.com/MHSanaei/3x-ui/v${ver}/x-ui.sh"
        if curl -fsIL -o /dev/null --max-time 8 "$u" 2>/dev/null; then
            echo "$u"; return
        fi
    fi
    echo "$RAW_MAIN"
}

# 缓存有效期 10 分钟, 避免每次执行都联网
need_fetch=1
if [[ -s "$CACHE" ]] && [[ -f /etc/x-ui/x-ui ]]; then
    ver_now=$(/etc/x-ui/x-ui -v 2>/dev/null | tr -d '[:space:]')
    ver_cached=$(head -3 "$CACHE" | grep -oE '3xui-zh-cache-v[0-9.]+' | sed 's/.*-v//')
    age=$(( $(date +%s) - $(stat -c %Y "$CACHE" 2>/dev/null || echo 0) ))
    [[ "$ver_now" == "$ver_cached" && $age -lt 600 ]] && need_fetch=0
fi

if [[ $need_fetch -eq 1 ]]; then
    url=$(pick_url)
    tmp=$(mktemp /tmp/xui-zh.XXXXXX)
    if curl -fsSL --max-time 20 -o "$tmp" "$url" && [[ -s "$tmp" ]]; then
        ver_now=$(/etc/x-ui/x-ui -v 2>/dev/null | tr -d '[:space:]' || echo "")
        { echo "# 3xui-zh-cache-v${ver_now} $url"; cat "$tmp"; } > "$CACHE"
        rm -f "$tmp"
    else
        rm -f "$tmp"
        # 拉取失败: 用已有缓存, 没缓存就用本地原始脚本
        [[ -s "$CACHE" ]] || {
            if [[ -f "$UPSTREAM" ]]; then
                cp -f "$UPSTREAM" "$CACHE"
            else
                echo "x-ui 未安装, 且无法获取脚本" >&2; exit 1
            fi
        }
    fi
fi

# 去掉首行缓存标记
raw=$(mktemp /tmp/xui-raw.XXXXXX)
sed '1{/^# 3xui-zh-cache-v/d}' "$CACHE" > "$raw"
zh=$(mktemp /tmp/xui-zh-out.XXXXXX)

# bash -n 只查语法; 上游改结构可能汉化后仍"语法合法"却行为错乱,
# 这里额外校验关键锚点是否还在, 确保汉化确实作用在正确的脚本上
anchor_ok=1
# x-ui.sh 的结构特征: 管理菜单函数 + 子命令分支
grep -q 'show_menu' "$raw" || anchor_ok=0
grep -q 'check_install' "$raw" || anchor_ok=0

if [[ $anchor_ok -eq 1 ]] && python3 "$ZH_DIR/zhify.py" "$raw" "$zh" 2>/dev/null && bash -n "$zh" 2>/dev/null; then
    chmod +x "$zh"
    "$zh" "$@"; rc=$?
    rm -f "$raw" "$zh"
    exit $rc
else
    # 汉化或语法检查失败: 直接跑原始脚本, 保证功能不残
    printf "\033[0;33m[!] 汉化失败, 本次以原版运行 (执行 x-ui-zh 选 1 修复)\033[0m\n" >&2
    bash "$raw" "$@"; rc=$?
    rm -f "$raw" "$zh"
    exit $rc
fi
WRAPEOF
chmod +x "$WRAPPER"
ok "wrapper 已安装: $WRAPPER"

# ---------- 4. 管理菜单 (数字选择) ----------
cat > /usr/local/bin/x-ui-zh << 'ZHEOF'
#!/usr/bin/env bash
# 3x-ui 中文菜单 —— 管理工具
Z=/etc/3xui-zh
UP=/usr/bin/x-ui

B="\033[0;34m"; G="\033[0;32m"; Y="\033[0;33m"; R="\033[0;31m"; P="\033[0m"
ok(){   printf "${G}[✓]${P} %s\n" "$*"; }
warn(){ printf "${Y}[!]${P} %s\n" "$*"; }
err(){  printf "${R}[✗]${P} %s\n" "$*" >&2; }

need_root(){ [[ $EUID -ne 0 ]] && { err "请用 root 运行"; return 1; }; }

do_fix(){
    local ver url
    ver=$(/etc/x-ui/x-ui -v 2>/dev/null | tr -d '[:space:]')
    [[ "$ver" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || ver=""
    url="https://raw.githubusercontent.com/MHSanaei/3x-ui/v${ver}/x-ui.sh"
    curl -fsIL -o /dev/null --max-time 8 "$url" 2>/dev/null \
        || url="https://raw.githubusercontent.com/MHSanaei/3x-ui/main/x-ui.sh"
    printf "拉取: %s\n" "$url"
    rm -f "$Z/upstream.sh"
    if ! curl -fsSL --max-time 30 -o /tmp/_up.sh "$url"; then
        err "下载失败, 已保留原缓存"
        return 1
    fi
    { printf '# 3xui-zh-cache-v%s %s\n' "$ver" "$url"; cat /tmp/_up.sh; } > "$Z/upstream.sh"
    rm -f /tmp/_up.sh
    ok "缓存已重建"
}

do_off(){
    if [[ ! -x "$UP" ]]; then err "未安装面板"; return 1; fi
    printf "已切到原版执行 (透传参数):\n\n"
    exec "$UP" "$@"
}

do_status(){
    printf "${B}── 当前状态 ──${P}\n"
    if [[ -f /usr/local/bin/x-ui ]] && grep -q "3xui-zh wrapper" /usr/local/bin/x-ui 2>/dev/null; then
        printf "  汉化层    : ${G}已启用${P}\n"
    else
        printf "  汉化层    : ${R}未启用${P}\n"
    fi
    printf "  汉化引擎  : %s\n" "$([ -f "$Z/zhify.py" ] && echo 已安装 || echo 缺失)"
    printf "  脚本缓存  : %s\n" "$([ -s "$Z/upstream.sh" ] && echo 有 || echo 无)"
    local bin=/etc/x-ui/x-ui pv=""
    if [[ -x "$bin" ]]; then
        pv=$("$bin" -v 2>/dev/null | tr -d '[:space:]')
        [[ "$pv" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || pv="未知"
        printf "  面板版本  : %s\n" "$pv"
    else
        printf "  面板版本  : ${Y}未安装${P}\n"
    fi
}

do_uninstall(){
    need_root || return 1
    printf "确认卸载中文菜单, 恢复官方原版? (y/n): "
    read -r c
    [[ "$c" != "y" && "$c" != "Y" ]] && { warn "已取消"; return 0; }
    if [[ -f "$Z/original-x-ui.sh" ]]; then
        cp -f "$Z/original-x-ui.sh" /usr/local/bin/x-ui
        ok "已恢复原版 x-ui"
    else
        rm -f /usr/local/bin/x-ui
        ok "已移除汉化层"
    fi
    rm -f /usr/local/bin/x-ui-zh
    rm -rf "$Z"
    ok "卸载完成"
}

menu(){
    printf "\n"
    printf "${B}╔──────────────────────────────────────────────╗${P}\n"
    printf "${B}│${P}  ${G}3x-ui 中文菜单 · 管理${P}                       ${B}│${P}\n"
    printf "${B}│──────────────────────────────────────────────│${P}\n"
    printf "${B}│${P}  ${G}1.${P} 刷新汉化 (上游更新后使用)                ${B}│${P}\n"
    printf "${B}│${P}  ${G}2.${P} 临时用原版英文 (进入官方菜单)            ${B}│${P}\n"
    printf "${B}│${P}  ${G}3.${P} 卸载汉化                                 ${B}│${P}\n"
    printf "${B}│${P}  ${G}4.${P} 查看当前状态                             ${B}│${P}\n"
    printf "${B}│${P}  ${G}0.${P} 退出                                     ${B}│${P}\n"
    printf "${B}╚──────────────────────────────────────────────╝${P}\n"
    do_status
    printf "\n请输入选项 [0-4]: "
    read -r n
    case "$n" in
        1) do_fix; menu ;;
        2) do_off; menu ;;
        3) do_uninstall; exit 0 ;;
        4) menu ;;
        0|"") exit 0 ;;
        *) err "请输入 0-4 之间的数字"; menu ;;
    esac
}

# 支持 x-ui-zh fix / off / uninstall / status 直接调用
case "${1:-}" in
    fix)       do_fix ;;
    off)       shift; do_off "$@" ;;
    uninstall) do_uninstall ;;
    status)    do_status ;;
    "")        menu ;;
    *)         printf "用法: x-ui-zh [fix|off|uninstall|status]\n"; exit 1 ;;
esac
ZHEOF
chmod +x /usr/local/bin/x-ui-zh
ok "管理命令: x-ui-zh (数字菜单)"

# ---------- 5. 自检 ----------
if [[ ! -x "$UPSTREAM" ]]; then
    warn "未检测到 $UPSTREAM (面板可能还没装), wrapper 已就位, 装完后直接敲 x-ui 即可"
else
    if bash "$WRAPPER" status > /dev/null 2>&1; then
        ok "自检通过: x-ui 中文版可正常运行"
    else
        warn "自检未通过, 请运行 x-ui-zh 选 1 刷新"
    fi
fi

echo
printf "${B}════════ 安装完成 ════════${P}\n"
printf "  直接敲  ${G}x-ui${P}           进入中文菜单\n"
printf "  ${Y}x-ui-zh${P}          管理菜单 (数字选择)\n"
printf "      ${G}1${P} 刷新汉化   ${G}2${P} 原版英文   ${G}3${P} 卸载\n"
printf "${B}═══════════════════════════${P}\n"
